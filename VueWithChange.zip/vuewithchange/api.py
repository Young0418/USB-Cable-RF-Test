# api.py (修改后)
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from controller import run
import uvicorn
import openai
import os

app = FastAPI(title="USB线缆检测API")

# CORS 配置（允许 Vue 开发服务器访问）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- DeepSeek 客户端初始化 ----------
DEEPSEEK_API_KEY = "sk-abe60d9d6d9f40c088600e8738e80821"
deepseek_client = openai.OpenAI(
    api_key=DEEPSEEK_API_KEY,
    base_url="https://api.deepseek.com/v1"
)

class AnalyzeRequest(BaseModel):
    cable_type: str
    length: float = 1.0

class AnalyzeResponse(BaseModel):
    device_info: dict
    cable_type: str
    qualified: bool
    message: str
    s11_qualified: bool
    s21_qualified: bool
    s11_data: list
    s21_data: list
    analysis_detail: dict

@app.post("/analyze", response_model=AnalyzeResponse)
async def analyze(request: AnalyzeRequest):
    try:
        result = run(request.cable_type, request.length)
        return result
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health():
    return {"status": "ok"}

# ---------- AI 代理接口 ----------
class ChatRequest(BaseModel):
    prompt: str
    system_prompt: str = "你是射频测试专家。"

class ChatHistoryRequest(BaseModel):
    messages: list[dict]  # [{"role": "user/assistant", "content": "..."}]
    system_prompt: str = "你是射频测试专家。"

@app.post("/ai/chat")
async def ai_chat(req: ChatRequest):
    try:
        response = deepseek_client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": req.system_prompt},
                {"role": "user", "content": req.prompt}
            ],
            temperature=0.7,
            max_tokens=2400
        )
        return {"reply": response.choices[0].message.content.strip()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/ai/chat/history")
async def ai_chat_history(req: ChatHistoryRequest):
    try:
        full_messages = [{"role": "system", "content": req.system_prompt}] + req.messages
        response = deepseek_client.chat.completions.create(
            model="deepseek-chat",
            messages=full_messages,
            temperature=0.7,
            max_tokens=2400
        )
        return {"reply": response.choices[0].message.content.strip()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=8001)