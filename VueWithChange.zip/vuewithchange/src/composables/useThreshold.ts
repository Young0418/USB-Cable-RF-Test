// 阈值常量定义
export const SUPPORTED_LENGTHS = [5, 10, 20]

export interface CableThresholdConfig {
  freqs: number[]
  S11: number[]
  S21: number[]
}

export const FREQ_THRESHOLDS: Record<string, Record<number, CableThresholdConfig>> = {
  RG316: {
    5: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-20, -21, -22, -23, -24], S21: [-1.0, -1.5, -2.0, -2.5, -3.0] },
    10: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-20, -21, -22, -23, -24], S21: [-2.0, -2.5, -3.0, -3.5, -4.0] },
    20: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-20, -21, -22, -23, -24], S21: [-3.0, -3.5, -4.0, -4.5, -5.0] }
  },
  RG58: {
    5: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-18, -19, -20, -21, -22], S21: [-2.0, -2.5, -3.0, -3.5, -4.0] },
    10: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-18, -19, -20, -21, -22], S21: [-3.0, -3.5, -4.0, -4.5, -5.0] },
    20: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-18, -19, -20, -21, -22], S21: [-4.0, -4.5, -5.0, -5.5, -6.0] }
  },
  '半刚电缆': {
    5: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-25, -26, -27, -28, -29], S21: [-0.5, -1.0, -1.5, -2.0, -2.5] },
    10: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-25, -26, -27, -28, -29], S21: [-1.0, -1.5, -2.0, -2.5, -3.0] },
    20: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-25, -26, -27, -28, -29], S21: [-1.5, -2.0, -2.5, -3.0, -3.5] }
  },
  RG174: {
    5: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-17, -18, -19, -20, -21], S21: [-2.5, -3.0, -3.5, -4.0, -4.5] },
    10: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-17, -18, -19, -20, -21], S21: [-4.0, -4.5, -5.0, -5.5, -6.0] },
    20: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-17, -18, -19, -20, -21], S21: [-6.0, -6.5, -7.0, -7.5, -8.0] }
  },
  'LMR-200': {
    5: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-22, -23, -24, -25, -26], S21: [-1.2, -1.7, -2.2, -2.7, -3.2] },
    10: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-22, -23, -24, -25, -26], S21: [-2.2, -2.7, -3.2, -3.7, -4.2] },
    20: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-22, -23, -24, -25, -26], S21: [-3.2, -3.7, -4.2, -4.7, -5.2] }
  },
  RG6: {
    5: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-20, -21, -22, -23, -24], S21: [-1.5, -2.0, -2.5, -3.0, -3.5] },
    10: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-20, -21, -22, -23, -24], S21: [-2.5, -3.0, -3.5, -4.0, -4.5] },
    20: { freqs: [1e9, 2e9, 3e9, 4e9, 5e9], S11: [-20, -21, -22, -23, -24], S21: [-3.5, -4.0, -4.5, -5.0, -5.5] }
  }
}

export const MEAN_THRESHOLDS: Record<string, any> = {
  RG316: { s11_mean_good: -20, s21_mean_good: -3, s11_mean_pass: -15, s21_mean_pass: -5 },
  RG58: { s11_mean_good: -18, s21_mean_good: -3.5, s11_mean_pass: -12, s21_mean_pass: -6 },
  '半刚电缆': { s11_mean_good: -22, s21_mean_good: -2.5, s11_mean_pass: -16, s21_mean_pass: -4.5 },
  RG174: { s11_mean_good: -17, s21_mean_good: -4, s11_mean_pass: -12, s21_mean_pass: -7 },
  'LMR-200': { s11_mean_good: -22, s21_mean_good: -3, s11_mean_pass: -17, s21_mean_pass: -5 },
  RG6: { s11_mean_good: -20, s21_mean_good: -3.5, s11_mean_pass: -15, s21_mean_pass: -5.5 }
}

export const DEFAULT_MEAN = {
  s11_mean_good: -15,
  s21_mean_good: -5,
  s11_mean_pass: -10,
  s21_mean_pass: -8
}

// 确保导出 DEFAULT_FREQ_THRESHOLD
export const DEFAULT_FREQ_THRESHOLD: CableThresholdConfig = {
  freqs: [1e9, 5e9],
  S11: [-20, -20],
  S21: [-3, -3]
}

export function getClosestLength(target: number, supported: number[]): number {
  return supported.reduce((prev, curr) => Math.abs(curr - target) < Math.abs(prev - target) ? curr : prev)
}

export function interpolate(x: number, xp: number[], fp: number[]): number {
  if (x <= xp[0]) return fp[0]
  if (x >= xp[xp.length - 1]) return fp[fp.length - 1]
  for (let i = 0; i < xp.length - 1; i++) {
    if (x >= xp[i] && x <= xp[i + 1]) {
      const t = (x - xp[i]) / (xp[i + 1] - xp[i])
      return fp[i] * (1 - t) + fp[i + 1] * t
    }
  }
  return fp[0]
}

import type { DetectionResult } from '@/types/detection'

export function buildThresholdComparisonText(
  result: DetectionResult,
  cableType: string,
  cableLength: number
): string {
  const closest = getClosestLength(cableLength, SUPPORTED_LENGTHS)
  const th = FREQ_THRESHOLDS[cableType]?.[closest] || DEFAULT_FREQ_THRESHOLD
  const meanTh = MEAN_THRESHOLDS[cableType] || DEFAULT_MEAN

  const freq = result.s11_data[0]
  const s11 = result.s11_data[1]
  const s21 = result.s21_data[1]

  let s11Points = []
  let s21Points = []
  for (let i = 0; i < Math.min(freq.length, 10); i++) {
    const f = freq[i]
    const s11Th = interpolate(f, th.freqs, th.S11)
    const s21Th = interpolate(f, th.freqs, th.S21)
    s11Points.push(`频率 ${(f / 1e9).toFixed(1)}GHz: 实测 ${s11[i].toFixed(1)}dB, 阈值 ${s11Th.toFixed(1)}dB, ${s11[i] < s11Th ? '合格' : '不合格'}`)
    s21Points.push(`频率 ${(f / 1e9).toFixed(1)}GHz: 实测 ${s21[i].toFixed(1)}dB, 阈值 ${s21Th.toFixed(1)}dB, ${s21[i] > s21Th ? '合格' : '不合格'}`)
  }

  return `
阈值标准（线缆类型：${cableType}，长度：${cableLength}m，实际使用阈值长度：${closest}m）
S11阈值：${th.S11.join(', ')} dB
S21阈值：${th.S21.join(', ')} dB
均值良好标准：S11均值 < ${meanTh.s11_mean_good}dB 且 S21均值 > ${meanTh.s21_mean_good}dB

逐点对比（部分）：
${s11Points.join('\n')}
${s21Points.join('\n')}

整体结果：S11整体${result.s11_qualified ? '合格' : '不合格'}，S21整体${result.s21_qualified ? '合格' : '不合格'}。
测量均值：S11均值 ${result.analysis_detail.s11_mean}dB，S21均值 ${result.analysis_detail.s21_mean}dB。
  `.trim()
}


export function getThresholds(cableType: string, length: number) {
  const closest = getClosestLength(length, SUPPORTED_LENGTHS)
  const config = FREQ_THRESHOLDS[cableType]?.[closest]
  if (!config) {
    return DEFAULT_FREQ_THRESHOLD
  }
  return config
}