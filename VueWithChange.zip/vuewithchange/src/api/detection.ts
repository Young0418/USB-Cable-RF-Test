import axios from 'axios'
import type { DetectionResult } from '@/types/detection'

const api = axios.create({
  baseURL: '/api', // 通过 Vite proxy 转发到 http://localhost:8001
  timeout: 30000,
})

export interface DetectionRequest {
  cable_type: string
  length: number
}

export const detectCable = async (params: DetectionRequest): Promise<DetectionResult> => {
  const response = await api.post<DetectionResult>('/analyze', params)
  return response.data
}
