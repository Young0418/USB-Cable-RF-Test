import axios from 'axios'

const aiApi = axios.create({
  baseURL: '/api/ai', // 需要后端提供 AI 代理接口
  timeout: 60000,
})

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

export const callDeepSeek = async (prompt: string, systemPrompt?: string): Promise<string> => {
  const response = await aiApi.post('/chat', { prompt, systemPrompt })
  return response.data.reply
}

export const callDeepSeekWithHistory = async (
  messages: ChatMessage[],
  systemPrompt?: string,
): Promise<string> => {
  const response = await aiApi.post('/chat/history', { messages, systemPrompt })
  return response.data.reply
}
