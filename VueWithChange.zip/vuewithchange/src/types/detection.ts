export interface DeviceInfo {
  model: string
  cable_type: string
  test_time: string
}

export interface AnalysisDetail {
  s11_mean: number
  s21_mean: number
  s11_max: number
  s21_min: number
}

export interface DetectionResult {
  qualified: boolean
  s11_qualified: boolean
  s21_qualified: boolean
  message: string
  cable_type: string
  device_info: DeviceInfo
  s11_data: [number[], number[]] // [freqs, mags]
  s21_data: [number[], number[]]
  analysis_detail: AnalysisDetail
}

export interface CableThresholdConfig {
  freqs: number[]
  S11: number[]
  S21: number[]
}
