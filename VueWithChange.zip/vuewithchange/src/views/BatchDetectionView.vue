<script setup lang="ts">
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage, ElMessageBox } from 'element-plus'
import { useDetectionStore } from '@/stores/detectionStore'
import { detectCable } from '@/api/detection'
import SParameterChart from '@/components/SParameterChart.vue'

const router = useRouter()
const detectionStore = useDetectionStore()

const batchCount = ref(3)
const batchMode = ref(false)
const batchIndex = ref(0)
const batchResults = ref<any[]>([])
const selectedBatchIdx = ref<number | null>(null)
const dialogVisible = ref(false)

const progressPercent = computed(() => {
  if (batchCount.value === 0) return 0
  return (batchIndex.value / batchCount.value) * 100
})

async function startBatch() {
  batchMode.value = true
  batchIndex.value = 0
  batchResults.value = []
  selectedBatchIdx.value = null
}

async function measureNext() {
  if (batchIndex.value >= batchCount.value) {
    batchMode.value = false
    ElMessage.success('批量检测完成！')
    return
  }

  try {
    const result = await detectCable({
      cable_type: detectionStore.cableType,
      length: detectionStore.cableLength,
    })
    batchResults.value.push(result)
    batchIndex.value++
  } catch (error: any) {
    ElMessage.error(`第 ${batchIndex.value + 1} 根线缆测量失败：${error.message}`)
    const shouldContinue = await ElMessageBox.confirm('是否继续测量下一根？', '测量失败', {
      confirmButtonText: '继续',
      cancelButtonText: '停止',
      type: 'warning',
    }).catch(() => false)
    if (!shouldContinue) {
      batchMode.value = false
    } else {
      batchIndex.value++
    }
  }
}

function cancelBatch() {
  batchMode.value = false
}

function resetBatch() {
  batchResults.value = []
  batchMode.value = false
}

function exportCSV() {
  const csvRows = []
  csvRows.push('序号,合格,S11合格,S21合格,消息')
  batchResults.value.forEach((r, i) => {
    csvRows.push(`${i + 1},${r.qualified},${r.s11_qualified},${r.s21_qualified},"${r.message}"`)
  })
  const csvString = csvRows.join('\n')
  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = 'batch_results.csv'
  link.click()
  URL.revokeObjectURL(link.href)
}

function goBack() {
  router.push('/')
}

function showCurve(index: number) {
  selectedBatchIdx.value = index
  dialogVisible.value = true
}

function closeDialog() {
  dialogVisible.value = false
  selectedBatchIdx.value = null
}
</script>

<template>
  <div class="batch-container">
    <el-card>
      <template #header>
        <div style="display: flex; justify-content: space-between; align-items: center">
          <span style="font-size: 18px; font-weight: bold">📦 批量检测模式</span>
          <el-button @click="goBack">返回单次检测</el-button>
        </div>
      </template>

      <!-- 未开始批量时显示设置 -->
      <div v-if="!batchMode && batchResults.length === 0">
        <el-form label-width="120px">
          <el-form-item label="线缆类型">
            <el-tag>{{ detectionStore.cableType }}</el-tag>
            <span style="margin-left: 10px; color: #909399">
              长度：{{ detectionStore.cableLength }} m
            </span>
          </el-form-item>
          <el-form-item label="批量数量">
            <el-input-number v-model="batchCount" :min="1" :max="20" />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="startBatch">开始批量测量</el-button>
          </el-form-item>
        </el-form>
      </div>

      <!-- 进行中 -->
      <div v-else-if="batchMode && batchIndex < batchCount">
        <el-progress :percentage="progressPercent" :stroke-width="20" :text-inside="true" />
        <div style="margin: 30px 0; text-align: center">
          <p style="font-size: 18px">
            请连接第 <strong>{{ batchIndex + 1 }}</strong> 根线缆，然后点击下方按钮开始测量
          </p>
          <el-button type="primary" size="large" @click="measureNext" style="margin: 20px">
            开始测量当前线缆
          </el-button>
          <el-button size="large" @click="cancelBatch">取消批量检测</el-button>
        </div>
      </div>

      <!-- 已完成 -->
      <div v-else-if="batchResults.length > 0">
        <el-alert type="success" :closable="false" style="margin-bottom: 20px">
          批量检测完成！共测量 {{ batchResults.length }} 根线缆。
        </el-alert>

        <el-table :data="batchResults" stripe style="width: 100%">
          <el-table-column type="index" label="序号" width="60" />
          <el-table-column label="结果" width="100">
            <template #default="{ row }">
              <el-tag :type="row.qualified ? 'success' : 'danger'">
                {{ row.qualified ? '合格' : '不合格' }}
              </el-tag>
            </template>
          </el-table-column>
          <el-table-column prop="message" label="详情" />
          <el-table-column label="操作" width="100">
            <template #default="{ $index }">
              <el-button link type="primary" @click="showCurve($index)"> 查看曲线 </el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- 曲线弹窗 -->
        <el-dialog
          v-model="dialogVisible"
          :title="`线缆 #${(selectedBatchIdx ?? 0) + 1} S参数曲线`"
          width="80%"
          @close="closeDialog"
        >
          <el-row :gutter="20">
            <el-col :span="12">
              <h4>S11</h4>
              <SParameterChart
                v-if="selectedBatchIdx !== null && batchResults[selectedBatchIdx]?.s11_data"
                :freq-data="batchResults[selectedBatchIdx].s11_data[0]"
                :mag-data="batchResults[selectedBatchIdx].s11_data[1]"
                parameter="S11"
              />
            </el-col>
            <el-col :span="12">
              <h4>S21</h4>
              <SParameterChart
                v-if="selectedBatchIdx !== null && batchResults[selectedBatchIdx]?.s21_data"
                :freq-data="batchResults[selectedBatchIdx].s21_data[0]"
                :mag-data="batchResults[selectedBatchIdx].s21_data[1]"
                parameter="S21"
              />
            </el-col>
          </el-row>
        </el-dialog>

        <div style="margin-top: 20px; text-align: right">
          <el-button type="success" @click="exportCSV">导出 CSV</el-button>
          <el-button @click="resetBatch">重新开始</el-button>
        </div>
      </div>
    </el-card>
  </div>
</template>

<style scoped>
.batch-container {
  padding: 20px;
  max-width: 1000px;
  margin: 0 auto;
}
</style>
