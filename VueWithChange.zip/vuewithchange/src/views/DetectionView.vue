<script setup lang="ts">
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { useDetectionStore } from '@/stores/detectionStore'
import { useHistoryStore } from '@/stores/historyStore'
import { useAIStore } from '@/stores/aiStore'
import CableSelector from '@/components/CableSelector.vue'
import SParameterChart from '@/components/SParameterChart.vue'
import AIAnalysisPanel from '@/components/AIAnalysisPanel.vue'
import HistoryPanel from '@/components/HistoryPanel.vue'
import { getThresholds } from '@/composables/useThreshold'

const detectionStore = useDetectionStore()
const historyStore = useHistoryStore()
const aiStore = useAIStore()

const showHistory = ref(false)

// 获取当前阈值（用于图表显示）
const currentThreshold = computed(() => {
  if (!detectionStore.currentResult) return { s11: undefined, s21: undefined }
  const th = getThresholds(detectionStore.cableType, detectionStore.cableLength)
  // 简化为取第一个频点的阈值（实际应插值）
  return {
    s11: th.S11[0],
    s21: th.S21[0],
  }
})

async function handleDetect() {
  try {
    await detectionStore.performDetection()
    ElMessage.success('检测完成')
    // 重置 AI 状态，为新检测准备
    aiStore.reset()
  } catch (error) {
    ElMessage.error('检测失败：' + error)
  }
}

function loadHistoryRecord(recordId: number) {
  const record = historyStore.getRecordById(recordId)
  if (record) {
    detectionStore.currentResult = record.result
    detectionStore.cableType = record.cableType
    detectionStore.cableLength = record.length
    aiStore.reset()
    showHistory.value = false
  }
}
</script>

<template>
  <div class="detection-container">
    <el-row :gutter="20">
      <!-- 左侧操作面板 -->
      <el-col :span="6">
        <el-card>
          <template #header>操作面板</template>
          <CableSelector
            v-model:cable-type="detectionStore.cableType"
            v-model:cable-length="detectionStore.cableLength"
          />
          <el-button
            type="primary"
            :loading="detectionStore.loading"
            @click="handleDetect"
            style="width: 100%; margin-top: 20px"
          >
            开始检测
          </el-button>

          <el-divider />

          <el-button @click="showHistory = !showHistory">
            {{ showHistory ? '隐藏' : '显示' }}历史记录
          </el-button>

          <!-- 批量检测入口 -->
          <el-button @click="$router.push('/batch')" style="margin-left: 10px">
            批量检测
          </el-button>
        </el-card>

        <HistoryPanel v-if="showHistory" @select="loadHistoryRecord" style="margin-top: 20px" />
      </el-col>

      <!-- 右侧结果显示区 -->
      <el-col :span="18">
        <div v-if="!detectionStore.currentResult" class="placeholder">
          <el-empty description="点击左侧“开始检测”获取结果" />
        </div>

        <template v-else>
          <el-card class="result-header">
            <div style="display: flex; justify-content: space-between">
              <span>
                设备型号：{{ detectionStore.currentResult.device_info.model }} | 测试时间：{{
                  detectionStore.currentResult.device_info.test_time
                }}
              </span>
              <el-tag
                :type="detectionStore.currentResult.qualified ? 'success' : 'danger'"
                size="large"
              >
                {{ detectionStore.currentResult.qualified ? '合格' : '不合格' }}
              </el-tag>
            </div>
            <p>{{ detectionStore.currentResult.message }}</p>
          </el-card>

          <el-row :gutter="20" style="margin-top: 20px">
            <el-col :span="12">
              <el-card>
                <template #header>
                  S11 参数
                  <el-tag
                    :type="detectionStore.currentResult.s11_qualified ? 'success' : 'warning'"
                    size="small"
                  >
                    {{ detectionStore.currentResult.s11_qualified ? '合格' : '不合格' }}
                  </el-tag>
                </template>
                <SParameterChart
                  :freq-data="detectionStore.currentResult.s11_data[0]"
                  :mag-data="detectionStore.currentResult.s11_data[1]"
                  parameter="S11"
                  :threshold-line="currentThreshold.s11"
                />
              </el-card>
            </el-col>
            <el-col :span="12">
              <el-card>
                <template #header>
                  S21 参数
                  <el-tag
                    :type="detectionStore.currentResult.s21_qualified ? 'success' : 'warning'"
                    size="small"
                  >
                    {{ detectionStore.currentResult.s21_qualified ? '合格' : '不合格' }}
                  </el-tag>
                </template>
                <SParameterChart
                  :freq-data="detectionStore.currentResult.s21_data[0]"
                  :mag-data="detectionStore.currentResult.s21_data[1]"
                  parameter="S21"
                  :threshold-line="currentThreshold.s21"
                />
              </el-card>
            </el-col>
          </el-row>

          <!-- AI 分析区域 -->
          <AIAnalysisPanel
            :result="detectionStore.currentResult"
            :cable-type="detectionStore.cableType"
            :cable-length="detectionStore.cableLength"
            style="margin-top: 20px"
          />
        </template>
      </el-col>
    </el-row>
  </div>
</template>

<style scoped>
.detection-container {
  padding: 20px;
}
.placeholder {
  height: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.result-header {
  background-color: #f5f7fa;
}
</style>
