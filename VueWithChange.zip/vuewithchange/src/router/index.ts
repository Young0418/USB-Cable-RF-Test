import { createRouter, createWebHistory } from 'vue-router'
import DetectionView from '@/views/DetectionView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'detection',
      component: DetectionView   // 确保组件存在
    },
    {
      path: '/batch',
      name: 'batch',
      component: () => import('@/views/BatchDetectionView.vue')
    }
  ]
})

export default router