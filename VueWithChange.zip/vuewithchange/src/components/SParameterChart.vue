<script setup lang="ts">
import { computed } from 'vue'
import VChart from 'vue-echarts'
import { use } from 'echarts/core'
import { LineChart } from 'echarts/charts'
import { GridComponent, TooltipComponent, MarkLineComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { EChartsOption } from 'echarts'

use([LineChart, GridComponent, TooltipComponent, MarkLineComponent, CanvasRenderer])

const props = defineProps<{
  freqData: number[] // 频率 (Hz)
  magData: number[] // 幅度 (dB)
  parameter: 'S11' | 'S21'
  thresholdLine?: number // 单频点阈值线（可扩展为数组）
}>()

const option = computed<EChartsOption>(() => {
  const freqMHz = props.freqData.map((f) => f / 1e6)
  const seriesData = freqMHz.map((f, i) => [f, props.magData[i]])

  const markLine =
    props.thresholdLine !== undefined
      ? {
          data: [{ yAxis: props.thresholdLine, name: '阈值' }],
          lineStyle: { color: 'red', type: 'dashed' },
        }
      : undefined

  return {
    xAxis: {
      type: 'value',
      name: '频率 (MHz)',
      axisLabel: { fontSize: 12 },
    },
    yAxis: {
      type: 'value',
      name: `${props.parameter} (dB)`,
      axisLabel: { fontSize: 12 },
    },
    series: [
      {
        data: seriesData,
        type: 'line',
        smooth: true,
        lineStyle: {
          color: props.parameter === 'S11' ? '#5470c6' : '#91cc75',
          width: 2,
        },
        markLine: markLine,
        symbol: 'none',
      },
    ],
    tooltip: {
      trigger: 'axis',
      valueFormatter: (value: number) => value.toFixed(2) + ' dB',
    },
    grid: {
      left: '8%',
      right: '5%',
      bottom: '10%',
    },
  }
})
</script>

<template>
  <v-chart :option="option" autoresize style="height: 300px" />
</template>
