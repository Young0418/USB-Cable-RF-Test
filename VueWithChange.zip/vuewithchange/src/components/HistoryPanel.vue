<script setup lang="ts">
import { useHistoryStore } from '@/stores/historyStore'

const historyStore = useHistoryStore()

const emit = defineEmits<{
  select: [id: number]
}>()

function formatDate(timestamp: string) {
  return timestamp.slice(5, 16) // 简化为 MM-DD HH:MM
}
</script>

<template>
  <el-card>
    <template #header>
      <div style="display: flex; justify-content: space-between">
        <span>历史记录</span>
        <el-button type="danger" link @click="historyStore.clearHistory">清空</el-button>
      </div>
    </template>
    <div
      v-if="historyStore.records.length === 0"
      style="text-align: center; padding: 20px; color: #909399"
    >
      暂无记录
    </div>
    <el-table :data="historyStore.records" size="small" style="width: 100%">
      <el-table-column label="时间" width="100">
        <template #default="{ row }">
          {{ formatDate(row.timestamp) }}
        </template>
      </el-table-column>
      <el-table-column prop="cableType" label="类型" width="80" />
      <el-table-column prop="length" label="长度(m)" width="70" />
      <el-table-column label="结果" width="70">
        <template #default="{ row }">
          <el-tag :type="row.qualified ? 'success' : 'danger'" size="small">
            {{ row.qualified ? '合格' : '不合格' }}
          </el-tag>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="60">
        <template #default="{ row }">
          <el-button link type="primary" @click="emit('select', row.id)">加载</el-button>
        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>
