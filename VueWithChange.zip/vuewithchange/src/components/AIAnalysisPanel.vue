<script setup lang="ts">
import { ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useAIStore } from '@/stores/aiStore'
import type { DetectionResult } from '@/types/detection'

const props = defineProps<{
  result: DetectionResult
  cableType: string
  cableLength: number
}>()

const aiStore = useAIStore()
const userQuestion = ref('')
const loading = ref(false)

async function startAnalysis() {
  loading.value = true
  try {
    await aiStore.startAnalysis(props.result, props.cableType, props.cableLength)
  } catch (error) {
    ElMessage.error('AI 分析失败：' + error)
  } finally {
    loading.value = false
  }
}

async function sendQuestion() {
  if (!userQuestion.value.trim()) return
  if (aiStore.remainingQuestions <= 0) {
    ElMessage.warning('提问次数已用完')
    return
  }
  const question = userQuestion.value
  userQuestion.value = ''
  loading.value = true
  try {
    await aiStore.askQuestion(question)
  } catch (error) {
    ElMessage.error('发送失败：' + error)
  } finally {
    loading.value = false
  }
}
</script>

<template>
  <el-card>
    <template #header>
      <span style="font-weight: bold">🤖 AI 智能分析</span>
      <el-button
        v-if="!aiStore.analysisTriggered"
        type="primary"
        link
        style="float: right"
        :loading="loading"
        @click="startAnalysis"
      >
        开始 AI 分析
      </el-button>
      <span v-else style="float: right; color: #909399">
        剩余提问次数：{{ aiStore.remainingQuestions }}
      </span>
    </template>

    <div v-if="!aiStore.analysisTriggered" style="text-align: center; padding: 20px">
      <p>点击上方按钮，让 AI 为您解读检测结果</p>
    </div>

    <div v-else class="chat-container">
      <div v-for="(msg, idx) in aiStore.conversation" :key="idx" class="message" :class="msg.role">
        <div class="avatar">{{ msg.role === 'assistant' ? '🤖' : '👤' }}</div>
        <div class="content">{{ msg.content }}</div>
      </div>

      <div v-if="aiStore.remainingQuestions > 0" class="input-area">
        <el-input
          v-model="userQuestion"
          placeholder="输入你的问题..."
          :disabled="loading"
          @keyup.enter="sendQuestion"
        >
          <template #append>
            <el-button :loading="loading" @click="sendQuestion">发送</el-button>
          </template>
        </el-input>
      </div>
      <el-alert v-else type="info" :closable="false" style="margin-top: 10px">
        提问次数已用完，如需继续咨询请重新检测。
      </el-alert>
    </div>
  </el-card>
</template>

<style scoped>
.chat-container {
  max-height: 400px;
  overflow-y: auto;
  padding: 10px;
}
.message {
  display: flex;
  margin-bottom: 15px;
}
.message.user {
  flex-direction: row-reverse;
}
.avatar {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  background: #e6f7ff;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 10px;
}
.message.user .avatar {
  background: #f0f0f0;
}
.content {
  background: #f5f5f5;
  padding: 10px 15px;
  border-radius: 18px;
  max-width: 70%;
  white-space: pre-wrap;
}
.message.user .content {
  background: #e6f7ff;
}
.input-area {
  margin-top: 15px;
}
</style>
