<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
  cableType: string
  cableLength: number
}>()

const emit = defineEmits<{
  'update:cableType': [value: string]
  'update:cableLength': [value: number]
}>()

const cableOptions = [
  'RG316',
  'RG58',
  '半刚电缆',
  'RG174',
  'LMR-200',
  'RG6'
]

// 使用 computed 代理 v-model
const localCableType = computed({
  get: () => props.cableType,
  set: (value) => emit('update:cableType', value)
})

const localCableLength = computed({
  get: () => props.cableLength,
  set: (value) => emit('update:cableLength', value)
})
</script>

<template>
  <el-form label-position="top">
    <el-form-item label="线缆类型">
      <el-select v-model="localCableType" placeholder="请选择" style="width: 100%">
        <el-option
          v-for="item in cableOptions"
          :key="item"
          :label="item"
          :value="item"
        />
      </el-select>
    </el-form-item>
    <el-form-item label="线缆长度 (m)">
      <el-input-number
        v-model="localCableLength"
        :min="0.1"
        :max="100"
        :step="0.1"
        controls-position="right"
        style="width: 100%"
      />
      <span class="hint">输入实际长度，系统自动匹配最接近的阈值长度</span>
    </el-form-item>
  </el-form>
</template>

<style scoped>
.hint {
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
  display: block;
}
</style>