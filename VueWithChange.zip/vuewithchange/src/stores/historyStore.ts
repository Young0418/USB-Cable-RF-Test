import { defineStore } from 'pinia'
import { ref } from 'vue'
import type { DetectionResult } from '@/types/detection'
import { useLocalStorage } from '@vueuse/core'

export interface HistoryRecord {
  id: number
  timestamp: string
  cableType: string
  length: number
  qualified: boolean
  message: string
  result: DetectionResult
}

export const useHistoryStore = defineStore('history', () => {
  // 使用 localStorage 持久化（生产环境建议改用后端数据库）
  const records = useLocalStorage<HistoryRecord[]>('cable-history', [])
  let nextId = records.value.length + 1

  function addRecord(result: DetectionResult, cableType: string, length: number) {
    const record: HistoryRecord = {
      id: nextId++,
      timestamp: new Date().toLocaleString(),
      cableType,
      length,
      qualified: result.qualified,
      message: result.message,
      result: JSON.parse(JSON.stringify(result)), // 深拷贝
    }
    records.value.unshift(record) // 最新在上
  }

  function clearHistory() {
    records.value = []
    nextId = 1
  }

  function getRecordById(id: number): HistoryRecord | undefined {
    return records.value.find((r) => r.id === id)
  }

  return { records, addRecord, clearHistory, getRecordById }
})
