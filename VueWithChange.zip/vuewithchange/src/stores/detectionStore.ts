import { defineStore } from 'pinia'
import { ref } from 'vue'
import { detectCable } from '@/api/detection'
import type { DetectionResult } from '@/types/detection'
import { useHistoryStore } from './historyStore'  // 导入

export const useDetectionStore = defineStore('detection', () => {
  const currentResult = ref<DetectionResult | null>(null)
  const cableType = ref('RG316')
  const cableLength = ref(5.0)
  const loading = ref(false)

  const batchMode = ref(false)
  const batchResults = ref<DetectionResult[]>([])
  const batchIndex = ref(0)
  const batchTotal = ref(0)

  async function performDetection() {
    loading.value = true
    try {
      const result = await detectCable({
        cable_type: cableType.value,
        length: cableLength.value
      })
      currentResult.value = result

      // 在函数内部调用其他 store
      const historyStore = useHistoryStore()
      historyStore.addRecord(result, cableType.value, cableLength.value)

      return result
    } finally {
      loading.value = false
    }
  }

  function resetBatch() {
    batchMode.value = false
    batchResults.value = []
    batchIndex.value = 0
    batchTotal.value = 0
  }

  return {
    currentResult, cableType, cableLength, loading,
    batchMode, batchResults, batchIndex, batchTotal,
    performDetection, resetBatch
  }
})