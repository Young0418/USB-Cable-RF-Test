import { defineStore } from 'pinia'
import { ref } from 'vue'
import { callDeepSeek, callDeepSeekWithHistory, type ChatMessage } from '@/api/ai'
import type { DetectionResult } from '@/types/detection'
import { buildThresholdComparisonText } from '@/composables/useThreshold' // 需实现

export const useAIStore = defineStore('ai', () => {
  const conversation = ref<ChatMessage[]>([])
  const remainingQuestions = ref(0)
  const analysisTriggered = ref(false)

  function reset() {
    conversation.value = []
    remainingQuestions.value = 0
    analysisTriggered.value = false
  }

  async function startAnalysis(result: DetectionResult, cableType: string, cableLength: number) {
    const comparisonText = buildThresholdComparisonText(result, cableType, cableLength)
    const prompt = `你是一位资深的射频线缆检测专家。请根据以下检测结果和阈值标准给出专业分析...\n${comparisonText}`

    const response = await callDeepSeek(prompt, '你是射频测试专家，熟悉S参数和线缆阈值标准。')
    conversation.value = [{ role: 'assistant', content: response }]
    remainingQuestions.value = 3
    analysisTriggered.value = true
  }

  async function askQuestion(question: string) {
    if (remainingQuestions.value <= 0) throw new Error('No questions left')

    conversation.value.push({ role: 'user', content: question })
    const response = await callDeepSeekWithHistory(
      conversation.value,
      '你是射频测试专家，请基于之前的检测数据和对话回答。',
    )
    conversation.value.push({ role: 'assistant', content: response })
    remainingQuestions.value--
  }

  return { conversation, remainingQuestions, analysisTriggered, reset, startAnalysis, askQuestion }
})
